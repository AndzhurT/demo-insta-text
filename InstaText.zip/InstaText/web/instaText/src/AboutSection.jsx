

function AboutSection() {
    return (
        <div className="p-4">
            <h1 className="text-2xl font-bold mb-4">About Section</h1>
        </div>
    );
}


export default AboutSection;